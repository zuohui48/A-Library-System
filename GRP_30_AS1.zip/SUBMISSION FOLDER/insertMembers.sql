INSERT INTO Member VALUES ("A101A", "Hermione Granger", "flying@als.edu", "Science","33336663");
INSERT INTO Member VALUES ("A201B", "Sherlock Holmes", "elementarydrw@als.edu", "Law","44327676");
INSERT INTO Member VALUES ("A301C", "Tintin", "luvmilu@als.edu", "Engineering","14358788");
INSERT INTO Member VALUES ("A401D", "Prinche Hamlet", "tobeornot@als.edu", "FASS","16091609");
INSERT INTO Member VALUES ("A5101E", "Willy Wonka", "choco1@als.edu", "FASS","19701970");
INSERT INTO Member VALUES ("A601F", "Holly Golightly", "diamond@als.edu", "Business","55548008");
INSERT INTO Member VALUES ("A701G", "Raskolnikov", "oneaxe@als.edu", "Law","18661866");
INSERT INTO Member VALUES ("A801H", "Patrick Bateman", "mice@als.edu", "Business","38548544");
INSERT INTO Member VALUES ("A901I", "Captain Ahab", "wwhale@als.edu", "Science","18511851");